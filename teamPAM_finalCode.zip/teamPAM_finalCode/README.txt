Hi Professor,

Our website is currently accessible at http://52.70.106.129/

Requirements Analysis:
Every user on our site has the same functionality--They are allowed to order food. A employee user would be something we could add in, who could see all the pending orders and mark when they are received/sent out for delivery/finished

Functional Analysis:
You can go online and see it in action. Click the login button, create an account, and then login using our username and password. You will be taken to an order screen, where you can place items into your cart. THe Remove All button will remove all of a selected item from your cart. Once finished, you can then add a tip, and then press checkout. You will then be taken to another page, where you can enter in your credit card details and any special instructions for the chef. Then you will be taken to another page, where you can give the items you ordered a rating.

Additional Features:
If given more time, we would consider adding:
More CSS/stylization post logging in
The time dependent notifications of “cooking,” “out for delivery,” and “delivered” while the user waits for their order
A visual interface for the user to see their past orders
Ability to change shipping addresses

Ali: rating system, contactUs.html, login functionality
Michael: orderPage.php, CSS styling, javascript control, index.html, linked all other pages together
Paul: Order completion page, credit card checking, database mangement/creation


Thanks,

Ali, Michael and Paul