<?php

session_start();

session_destroy();

echo "<script>window.open('login2.php','_self')</script>";

?>