
$(document).ready(function () {
        
    $("#Visa").click(function () {
        $('#drop_button').text('Visa');
    });
    
    $("#Master").click(function () {
        $('#drop_button').text('Master');
    });    
    
    $("#American_Express").click(function () {
        $('#drop_button').text('American Express');
    });    
});
